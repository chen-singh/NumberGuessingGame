import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        //this is a way 2 for easy understanding
        Scanner sc=new Scanner(System.in);
        int usernum;
        int attempts=0;
        int compnum= (int) (Math.random() * 100);
        System.out.println("Guess a number");
        do {
            usernum=sc.nextInt();
            if (usernum==compnum) {
                System.out.println("Congrats! you win the game"+"  " + ++attempts+" "+"attempts");
                System.exit(0);
            } else if (usernum>compnum) {
                System.out.println("large");
            } else if (usernum<compnum) {
                System.out.println("small");
            } else {
                System.out.println("Lose , Try Again");
            }
            attempts++;
        } while (true);

    }
}