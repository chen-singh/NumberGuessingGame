import java.util.Scanner;

public class NumberGuess {
    public static void main(String[] args) {

     // this is way one
        int compnum= (int) (Math.random() * 100);
        Scanner sc=new Scanner(System.in);
        int usernum;
        int attempts=0;
        System.out.println("Guess a number");
        do {
            usernum=sc.nextInt();
            if (usernum==compnum) {
                System.out.println("Congrats! you win the game"+"  " + ++attempts+" "+"attempts");
            System.exit(0);
            }
            else {
                System.out.println("Lose , Try Again");
            }
           attempts++;
        } while (true);

    }
}
